def get_response(message):
    return "You said: " + message
